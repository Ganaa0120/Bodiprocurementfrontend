export const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

export const STATUS_CFG: Record<
  string,
  { label: string; color: string; bg: string; dot: string }
> = {
  new: {
    label: "Бүртгэл үүсгэж буй",
    color: "#0369a1",
    bg: "rgba(14,165,233,0.12)",
    dot: "#0ea5e9",
  },
  pending: {
    label: "Хүлээгдэж буй",
    color: "#d97706",
    bg: "rgba(245,158,11,0.12)",
    dot: "#f59e0b",
  },
  active: {
    label: "Баталгаажсан",
    color: "#059669",
    bg: "rgba(16,185,129,0.12)",
    dot: "#10b981",
  },
  approved: {
    label: "Баталгаажсан",
    color: "#059669",
    bg: "rgba(16,185,129,0.12)",
    dot: "#10b981",
  },
  returned: {
    label: "Буцаагдсан",
    color: "#dc2626",
    bg: "rgba(239,68,68,0.12)",
    dot: "#ef4444",
  },
  inactive: {
    label: "Идэвхгүй",
    color: "#64748b",
    bg: "rgba(100,116,139,0.12)",
    dot: "#94a3b8",
  },
  rejected: {
    label: "Татгалзсан",
    color: "#dc2626",
    bg: "rgba(239,68,68,0.12)",
    dot: "#ef4444",
  },
};

export const STATUS_ACTIONS = [
  {
    status: "active",
    label: "Баталгаажуулах",
    color: "#10b981",
    bg: "rgba(16,185,129,0.12)",
    border: "rgba(16,185,129,0.3)",
  },
  {
    status: "returned",
    label: "Буцаах",
    color: "#f59e0b",
    bg: "rgba(245,158,11,0.10)",
    border: "rgba(245,158,11,0.28)",
  },
  {
    status: "inactive",
    label: "Идэвхгүй болгох",
    color: "#94a3b8",
    bg: "rgba(148,163,184,0.08)",
    border: "rgba(148,163,184,0.22)",
  },
];

export const ORG_COLORS = ["#34d399", "#3b82f6", "#a78bfa", "#fbbf24", "#fb923c"];